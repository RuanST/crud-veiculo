package br.com.veiculo.utils;

public final class MensagemErroConstants {
	
	 public static final String CADASTRADO_COM_SUCESSO = "Cadastrado com sucesso";
	 public static final String EXCLUIDO_COM_SUCESSO = "Excluido com sucesso";

}
